﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjektW68564

{
        internal class Sprzet
        {



            public int? Id { get; set; }
            public string? Nazwa { get; set; }
            public string ?Typ { get; set; }
            public decimal? CenaWypozyczenia { get; set; }
            public bool Dostepny { get; set; }
            public Sprzet() { }
            public Sprzet(int id, string nazwa, string typ, decimal cenaWypozyczenia, bool dostepny)
            {
                Id = id;
                Nazwa = nazwa;
                Typ = typ;
                CenaWypozyczenia = cenaWypozyczenia;
                Dostepny = dostepny;
            }

            public string WyświetlajInformacje()
            {
                string dostepnosc = Dostepny ? "Dostępny" : "Niedostępny";
                return $"ID: {Id}, Nazwa: {Nazwa}, Typ: {Typ}, Cena: {CenaWypozyczenia:C}, Dostępność: {dostepnosc}";
            }
        }

}
