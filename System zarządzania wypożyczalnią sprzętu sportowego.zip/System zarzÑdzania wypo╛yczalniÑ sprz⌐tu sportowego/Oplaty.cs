﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjektW68564
{
   internal class Oplaty
    {
        public decimal CenaWypozyczenia { get; set; }
        public DateTime DataWypozyczenia { get; set; }
        public DateTime DataZwrotu { get; set; }

        public decimal NaliczOplate()
        {
            // Obliczanie liczby dni wypożyczenia
            int liczbaDni = (int)Math.Ceiling((DataZwrotu - DataWypozyczenia).TotalDays);

            // Minimalna opłata za 1 dzień wypożyczenia
            if (liczbaDni < 1)
            {
                liczbaDni = 1;
            }

            // Naliczanie opłaty
            decimal oplata = CenaWypozyczenia * liczbaDni;

            return oplata;
        }

        public void WydrukujParagon()
        {
            Console.WriteLine("Paragon:");
            Console.WriteLine($"Data wypożyczenia: {DataWypozyczenia.ToShortDateString()}");
            Console.WriteLine($"Data zwrotu: {DataZwrotu.ToShortDateString()}");
            Console.WriteLine($"Liczba dni: {(DataZwrotu - DataWypozyczenia).Days}");
            Console.WriteLine($"Cena za dzień: {CenaWypozyczenia:C2}");
            Console.WriteLine($"Całkowita opłata: {NaliczOplate():C2}");
        }
    }
}
