﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySqlConnector;
namespace ProjektW68564
{
    internal class ZarzadzanieKlientami
    {

        private string connectionString = "server=localhost;database=projekt;uid=root;pwd=;";


        public void DodajKlienta(Klient klient)
        {
            using (var conn = new MySqlConnection(connectionString))
            {
                conn.Open();
                var query = "INSERT INTO klienci (imieNazwisko, numerTelefonu) VALUES (@imieNazwisko, @numerTelefonu)";
                using (var cmd = new MySqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@imieNazwisko", klient.ImieNazwisko);
                    cmd.Parameters.AddWithValue("@numerTelefonu", klient.NumerTelefonu);
                    cmd.ExecuteNonQuery();
                }
                Console.WriteLine("Dodano nowego klienta.");
            }
        }

        public void EdytujKlienta(int id, Klient nowyKlient)
        {
            using (var conn = new MySqlConnection(connectionString))
            {
                conn.Open();
                var query = "UPDATE klienci SET imieNazwisko = @imieNazwisko, numerTelefonu = @numerTelefonu WHERE id = @id";
                using (var cmd = new MySqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@id", id);
                    cmd.Parameters.AddWithValue("@imieNazwisko", nowyKlient.ImieNazwisko);
                    cmd.Parameters.AddWithValue("@numerTelefonu", nowyKlient.NumerTelefonu);
                    int result = cmd.ExecuteNonQuery();
                    if (result > 0)
                    {
                        Console.WriteLine("Dane klienta zostały zaktualizowane.");
                    }
                    else
                    {
                        Console.WriteLine("Nie znaleziono klienta o podanym identyfikatorze.");
                    }
                }
            }
        }

        public void UsunKlienta(int id)
        {
            using (var conn = new MySqlConnection(connectionString))
            {
                conn.Open();
                var query = "DELETE FROM klienci WHERE id = @id";
                using (var cmd = new MySqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@id", id);
                    int result = cmd.ExecuteNonQuery();
                    if (result > 0)
                    {
                        Console.WriteLine("Klient został usunięty.");
                    }
                    else
                    {
                        Console.WriteLine("Nie znaleziono klienta o podanym identyfikatorze.");
                    }
                }
            }
        }


    }
}
