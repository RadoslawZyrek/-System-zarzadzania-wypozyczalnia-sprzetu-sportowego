﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjektW68564
{
    internal class Wypozyczenie
    {
       
      
        public int? Id { get; set; }
        public Sprzet Sprzet { get; set; }
        public Klient Klient { get; set; }
        public DateTime DataWypozyczenia { get; set; }
        public DateTime DataZwrotu { get; set; }
        public decimal? CenaWypozyczenia { get; set; }


        public Wypozyczenie(int id, Sprzet sprzet, Klient klient, DateTime dataWypozyczenia, DateTime dataZwrotu, decimal cenaWypozyczenia)
        {
            Id = id;
            Sprzet = sprzet;
            Klient = klient;
            DataWypozyczenia = dataWypozyczenia;
            DataZwrotu = dataZwrotu;
            CenaWypozyczenia = cenaWypozyczenia;
        }

       

       
    }
}


