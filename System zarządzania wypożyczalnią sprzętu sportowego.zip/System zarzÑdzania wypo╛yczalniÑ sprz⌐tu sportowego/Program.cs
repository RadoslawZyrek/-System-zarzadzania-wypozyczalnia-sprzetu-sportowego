﻿using ProjektW68564;
using System.Xml.Linq;
using MySqlConnector;
using System.Globalization;
using static ProjektW68564.ZarzadzanieWypożyczeniami;
namespace ProjektW68564
{
    class Program
    {
        static ZarzadzanieSprzetem zarzadzanieSprzetem = new ZarzadzanieSprzetem();
        static ZarzadzanieKlientami zarzadzanieKlientami = new ZarzadzanieKlientami();
        static ZarzadzanieWypożyczeniami zarzadzanieWypożyczeniami = new ZarzadzanieWypożyczeniami();

        static void Main(string[] args)


        {

            var klient = new Klient
            {
                Id = 1,
                ImieNazwisko = "Jan Kowalski",
                NumerTelefonu = "500-600-700"
            };

            var sprzet = new Sprzet
            {
                Id = 1,
                Nazwa = "Rower górski",
                Typ = "Rower",
                CenaWypozyczenia = 50.00m, // zakładając, że cena jest typu decimal
                Dostepny = true
            };

            var rezerwacja = new Rezerwacja
            {
                Id = 1,
                Sprzet = sprzet,
                Klient = klient,
                DataRezerwacji = new DateTime(2024, 2, 27) // przykładowa data
            };
            string connectionString = "Server=localhost;Port=3306;Database=projekt;Uid=root;Pwd=;";

            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                try
                {
                    // Otwieramy połączenie
                    connection.Open();
                    Console.WriteLine("Połączono z bazą projekt");


                }
                catch (Exception ex)
                {
                    Console.WriteLine("Wystąpił błąd: " + ex.Message);
                }
            }
            Console.WriteLine("Naciśnij dowolny klawisz, aby zakończyć...");
            Console.ReadKey();
            while (true)



            {
                Console.Clear();
                Console.WriteLine("Wybierz sekcję:");
                Console.WriteLine("1. Zarządzanie sprzętem");
                Console.WriteLine("2. Zarządzanie klientami");
                Console.WriteLine("3. Zarządzanie wypożyczeniami");
                Console.WriteLine("4. Wyjście");

                string wybor = Console.ReadLine();

                switch (wybor)
                {
                    case "1":
                        Console.Clear();
                        SekcjaSprzetu();
                        break;
                    case "2":
                        Console.Clear();
                        SekcjaKlienta();
                        break;
                    case "3":
                        Console.Clear();
                        SekcjaWypozyczen();
                        break;
                    case "4":
                        Console.Clear();
                        Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("Niepoprawny wybór. Wybierz ponownie.");
                        break;
                }
            }
        }

        static void SekcjaSprzetu()
        {
            while (true)
            {
                Console.Clear();
                Console.WriteLine("Zarządzanie sprzętem:");
                Console.WriteLine("1. Dodaj nowy sprzęt");
                Console.WriteLine("2. Edytuj sprzęt");
                Console.WriteLine("3. Usuń sprzęt");
                Console.WriteLine("4. Wyświetl dostępny sprzęt");
                Console.WriteLine("5. Powrót");
                string wybor = Console.ReadLine();
                switch (wybor)
                {
                    case "1":

                        DodajSprzet();
                        break;
                    case "2":

                        EdytujSprzet();
                        break;
                    case "3":

                        UsunSprzet();
                        break;
                    case "4":
                        zarzadzanieSprzetem.WczytajDaneSprzetuZBazyDanych();
                        zarzadzanieSprzetem.WyswietlSprzet();
                        break;
                    case "5":
                        Console.Clear();
                        return;
                    default:
                        Console.Clear();
                        Console.WriteLine("Niepoprawny wybór. Wybierz ponownie.");
                        break;
                }
            }
        }

        static void DodajSprzet()
        {
            Console.WriteLine("Dodawanie nowego sprzętu:");
            Console.Write("Podaj nazwę sprzętu: ");
            string nazwa = Console.ReadLine();
            Console.Write("Podaj typ sprzętu: ");
            string typ = Console.ReadLine();
            Console.Write("Podaj cenę wypożyczenia sprzętu: ");
            decimal cenaWypozyczenia;
            while (!decimal.TryParse(Console.ReadLine(), out cenaWypozyczenia) || cenaWypozyczenia <= 0)
            {
                Console.WriteLine("Podano niepoprawną cenę. Podaj cenę wypożyczenia sprzętu:");
            }
            Console.Write("Czy sprzęt jest dostępny? (true/false): ");
            bool dostepny;
            while (!bool.TryParse(Console.ReadLine(), out dostepny))
            {
                Console.WriteLine("Podano niepoprawną wartość. Podaj czy sprzęt jest dostępny (true/false):");
            }

            zarzadzanieSprzetem.DodajNowySprzet(nazwa, typ, cenaWypozyczenia, dostepny);
        }
        static void EdytujSprzet()
        {
            Console.WriteLine("Edycja sprzętu:");
            Console.Write("Podaj ID sprzętu do edycji: ");
            int id;
            while (!int.TryParse(Console.ReadLine(), out id) || id <= 0)
            {
                Console.WriteLine("Podano niepoprawne ID. Podaj ID sprzętu do edycji:");
            }

            // Pobierz dane nowego sprzętu od użytkownika
            Console.WriteLine("Podaj nowe dane sprzętu:");
            Console.Write("Podaj nową nazwę sprzętu: ");
            string nazwa = Console.ReadLine();
            Console.Write("Podaj nowy typ sprzętu: ");
            string typ = Console.ReadLine();
            Console.Write("Podaj nową cenę wypożyczenia sprzętu: ");
            decimal cena;
            while (!decimal.TryParse(Console.ReadLine(), out cena) || cena <= 0)
            {
                Console.WriteLine("Podano niepoprawną cenę. Podaj nową cenę wypożyczenia sprzętu:");
            }
            Console.Write("Czy sprzęt jest dostępny? (true/false): ");
            bool dostepny;
            while (!bool.TryParse(Console.ReadLine(), out dostepny))
            {
                Console.WriteLine("Podano niepoprawną wartość. Podaj czy sprzęt jest dostępny (true/false):");
            }

            // Wywołaj metodę edycji sprzętu z klasy ZarzadzanieSprzetem
            zarzadzanieSprzetem.EdytujSprzet(id, new Sprzet(id, nazwa, typ, cena, dostepny));
        }

        static void UsunSprzet()
        {

            Console.WriteLine("Usuwanie sprzętu:");
            Console.Write("Podaj ID sprzętu do usunięcia: ");
            int id;
            while (!int.TryParse(Console.ReadLine(), out id) || id <= 0)
            {
                Console.WriteLine("Podano niepoprawne ID. Podaj ID sprzętu do usunięcia:");
            }
            // Wywołaj metodę usuwania sprzętu z klasy ZarzadzanieSprzetem
            zarzadzanieSprzetem.UsunSprzet(id);


        }
        static void SekcjaKlienta()
        {

            bool powrot = false;
            while (!powrot)
            {
                Console.Clear();
                Console.WriteLine("=== Sekcja Klienta ===");
                Console.WriteLine("1. Dodaj klienta");
                Console.WriteLine("2. Edytuj klienta");
                Console.WriteLine("3. Usuń klienta");
                Console.WriteLine("4. Powrót do głównego menu");
                Console.Write("Wybierz opcję: ");
                string opcja = Console.ReadLine();

                switch (opcja)
                {
                    case "1":
                        Console.Clear();
                        DodajKlienta(zarzadzanieKlientami);
                        break;
                    case "2":
                        Console.Clear();
                        EdytujKlienta(zarzadzanieKlientami);
                        break;
                    case "3":
                        Console.Clear();
                        UsunKlienta(zarzadzanieKlientami);
                        break;
                    case "4":
                        powrot = true;
                        break;
                    default:
                        Console.WriteLine("Nieznana opcja, spróbuj ponownie.");
                        break;
                }
                if (!powrot)
                {
                    Console.WriteLine("Naciśnij dowolny klawisz, aby kontynuować...");
                    Console.ReadKey();
                }

            }
            static void DodajKlienta(ZarzadzanieKlientami zarzadzanieKlientami)
            {
                Console.Write("Podaj ID klienta: ");
                int id = int.Parse(Console.ReadLine());
                Console.Write("Podaj imię i nazwisko klienta: ");
                string imieNazwisko = Console.ReadLine();
                Console.Write("Podaj numer telefonu klienta: ");
                string numerTelefonu = Console.ReadLine();

                Klient nowyKlient = new Klient(id, imieNazwisko, numerTelefonu);
                zarzadzanieKlientami.DodajKlienta(nowyKlient);
            }
            static void EdytujKlienta(ZarzadzanieKlientami zarzadzanieKlientami)
            {
                Console.Write("Podaj ID klienta do edycji: ");
                int id = int.Parse(Console.ReadLine());
                Console.Write("Podaj nowe imię i nazwisko klienta: ");
                string imieNazwisko = Console.ReadLine();
                Console.Write("Podaj nowy numer telefonu klienta: ");
                string numerTelefonu = Console.ReadLine();

                Klient nowyKlient = new Klient(id, imieNazwisko, numerTelefonu);
                zarzadzanieKlientami.EdytujKlienta(id, nowyKlient);
            }
            static void UsunKlienta(ZarzadzanieKlientami zarzadzanieKlientami)
            {
                Console.Write("Podaj ID klienta do usunięcia: ");
                int id = int.Parse(Console.ReadLine());
                zarzadzanieKlientami.UsunKlienta(id);
            }
        }

        static void SekcjaWypozyczen()
        {

            bool powrot = false;
            while (!powrot)
            {
                Console.Clear();
                Console.WriteLine("=== Sekcja Wypożyczeń ===");
                Console.WriteLine("1. Wypożycz Sprzet");
                Console.WriteLine("2. Zwroc Sprzet");
                Console.WriteLine("3. Zarezerwuj Sprzet");
                Console.WriteLine("4. Anuluj Rezerwacje");
                Console.WriteLine("5. Powrót do głównego menu");
                Console.Write("Wybierz opcję: ");
                string opcja = Console.ReadLine();

                switch (opcja)
                {
                    case "1":
                        Console.Clear();
                        WypozyczSprzet();
                        break;
                    case "2":
                        Console.Clear();
                        ZwrocSprzet();
                        break;
                    case "3":
                        Console.Clear();
                        ZarezerwujSprzet();
                        break;
                    case "4":
                        Console.Clear();
                        AnulujRezerwacje();
                        break;
                    case "5":
                        powrot = true;
                        break;
                    default:
                        Console.WriteLine("Nieznana opcja, spróbuj ponownie.");
                        break;
                }
                if (!powrot)
                {
                    Console.WriteLine("Naciśnij dowolny klawisz, aby kontynuować...");
                    Console.ReadKey();
                }
            }


        }
        static void WypozyczSprzet()
        {
            Console.WriteLine("Wypożyczanie sprzętu:");
            Console.Write("Podaj ID sprzętu do wypożyczenia: ");
            int sprzetId;
            while (!int.TryParse(Console.ReadLine(), out sprzetId) || sprzetId <= 0)
            {
                Console.WriteLine("Podano niepoprawne ID. Podaj ID sprzętu do wypożyczenia:");
            }

            Console.Write("Podaj ID klienta: ");
            int klientId;
            while (!int.TryParse(Console.ReadLine(), out klientId) || klientId <= 0)
            {
                Console.WriteLine("Podano niepoprawne ID klienta. Podaj ID klienta:");
            }

            Console.Write("Podaj datę wypożyczenia (RRRR-MM-DD): ");
            DateTime dataWypozyczenia;
            while (!DateTime.TryParseExact(Console.ReadLine(), "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None, out dataWypozyczenia))
            {
                Console.WriteLine("Podano niepoprawną datę. Podaj datę wypożyczenia (RRRR-MM-DD):");
            }

            Console.Write("Podaj datę planowanego zwrotu (RRRR-MM-DD): ");
            DateTime dataZwrotu;
            while (!DateTime.TryParseExact(Console.ReadLine(), "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None, out dataZwrotu))
            {
                Console.WriteLine("Podano niepoprawną datę. Podaj datę planowanego zwrotu (RRRR-MM-DD):");
            }

            zarzadzanieWypożyczeniami.WypozyczSprzet(sprzetId, klientId, dataWypozyczenia, dataZwrotu);
        }


        static void ZwrocSprzet()
        {
            Console.WriteLine("Zwracanie sprzętu:");
            Console.Write("Podaj ID sprzętu do zwrotu: ");
            int sprzetId;
            while (!int.TryParse(Console.ReadLine(), out sprzetId) || sprzetId <= 0)
            {
                Console.WriteLine("Podano niepoprawne ID. Podaj ID sprzętu do zwrotu:");
            }

            Console.Write("Podaj datę zwrotu (RRRR-MM-DD): ");
            DateTime dataZwrotu;
            while (!DateTime.TryParseExact(Console.ReadLine(), "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None, out dataZwrotu))
            {
                Console.WriteLine("Podano niepoprawną datę. Podaj datę zwrotu (RRRR-MM-DD):");
            }

            zarzadzanieWypożyczeniami.ZwrocSprzet(sprzetId, dataZwrotu);
        }
        static void ZarezerwujSprzet()
        {
            Console.WriteLine("Rezerwowanie sprzętu:");

            // Pobierz ID sprzętu do rezerwacji
            Console.Write("Podaj ID sprzętu do zarezerwowania: ");
            int sprzetId;
            while (!int.TryParse(Console.ReadLine(), out sprzetId) || sprzetId <= 0)
            {
                Console.WriteLine("Podano niepoprawne ID. Podaj ID sprzętu do zarezerwowania:");
            }

            // Pobierz ID klienta
            Console.Write("Podaj ID klienta: ");
            int klientId;
            while (!int.TryParse(Console.ReadLine(), out klientId) || klientId <= 0)
            {
                Console.WriteLine("Podano niepoprawne ID klienta. Podaj ID klienta:");
            }

            // Pobierz datę rezerwacji
            Console.Write("Podaj datę rezerwacji (RRRR-MM-DD): ");
            DateTime dataRezerwacji;
            while (!DateTime.TryParseExact(Console.ReadLine(), "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None, out dataRezerwacji))
            {
                Console.WriteLine("Podano niepoprawną datę. Podaj datę rezerwacji w formacie RRRR-MM-DD:");
            }

            // Wywołaj metodę rezerwacji sprzętu z klasy ZarzadzanieWypozyczeniami
            zarzadzanieWypożyczeniami.ZarezerwujSprzet(sprzetId, klientId, dataRezerwacji);
        }
        static void AnulujRezerwacje()
        {
            Console.WriteLine("Anulowanie rezerwacji:");

            // Pobierz ID rezerwacji do anulowania
            Console.Write("Podaj ID rezerwacji do anulowania: ");
            int rezerwacjaId;
            while (!int.TryParse(Console.ReadLine(), out rezerwacjaId) || rezerwacjaId <= 0)
            {
                Console.WriteLine("Podano niepoprawne ID. Podaj ID rezerwacji do anulowania:");
            }

            // Wywołaj metodę anulowania rezerwacji z klasy ZarzadzanieWypozyczeniami
           zarzadzanieWypożyczeniami.AnulujRezerwacje(rezerwacjaId);
        }

    }

}  
    



    

   
            

    

 