﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySqlConnector;
namespace ProjektW68564
{
    internal class ZarzadzanieWypożyczeniami
    {



        private string connectionString = "server=localhost;database=projekt;uid=root;pwd=;";

        public void WypozyczSprzet(int sprzetId, int klientId, DateTime dataWypozyczenia, DateTime dataZwrotu)
        {


            decimal cenaWypozyczenia = 0;
            using (var conn = new MySqlConnection(connectionString))
            {
                conn.Open();

                // Pobierz cenę za dzień dla sprzętu
                var queryCena = "SELECT cenaWypozyczenia FROM sprzet WHERE id = @sprzetId";
                using (var cmdCena = new MySqlCommand(queryCena, conn))
                {
                    cmdCena.Parameters.AddWithValue("@sprzetId", sprzetId);

                    cenaWypozyczenia = (decimal)cmdCena.ExecuteScalar();
                }

                var querySprzet = "UPDATE sprzet SET dostepny = false WHERE id = @sprzetId AND dostepny = true";
                var queryWypozyczenie = "INSERT INTO wypozyczenia (sprzetId, klientId, dataWypozyczenia, dataZwrotu, cenaCalkowita) VALUES (@sprzetId, @klientId, @dataWypozyczenia, @dataZwrotu, @cenaCalkowita)";

                using (var transaction = conn.BeginTransaction())
                {
                    using (var cmdSprzet = new MySqlCommand(querySprzet, conn, transaction))
                    {
                        cmdSprzet.Parameters.AddWithValue("@sprzetId", sprzetId);
                        var result = cmdSprzet.ExecuteNonQuery();
                        if (result == 0)
                        {
                            // Sprzęt nie jest dostępny lub nie istnieje
                            Console.WriteLine("Sprzęt nie jest dostępny lub nie istnieje.");
                            return;
                        }
                    }

                    // Utwórz obiekt opłat
                    var oplaty = new Oplaty
                    {
                        CenaWypozyczenia = cenaWypozyczenia,
                        DataWypozyczenia = dataWypozyczenia,
                        DataZwrotu = dataZwrotu
                    };

                    // Nalicz opłatę
                    decimal oplata = oplaty.NaliczOplate();

                    // Wstaw dane wypożyczenia do bazy danych
                    using (var cmdWypozyczenie = new MySqlCommand(queryWypozyczenie, conn, transaction))
                    {
                        cmdWypozyczenie.Parameters.AddWithValue("@sprzetId", sprzetId);
                        cmdWypozyczenie.Parameters.AddWithValue("@klientId", klientId);
                        cmdWypozyczenie.Parameters.AddWithValue("@dataWypozyczenia", dataWypozyczenia);
                        cmdWypozyczenie.Parameters.AddWithValue("@dataZwrotu", dataZwrotu);
                        cmdWypozyczenie.Parameters.AddWithValue("@cenaCalkowita", oplata);
                        cmdWypozyczenie.ExecuteNonQuery();
                    }

                    transaction.Commit();
                    Console.WriteLine("Wypożyczenie zostało zarejestrowane.");

                    // Wydruk paragonu
                    oplaty.WydrukujParagon();
                }
            }
        }


        public void ZwrocSprzet(int sprzetId, DateTime dataZwrotu)
        {
            using (var conn = new MySqlConnection(connectionString))
            {
                conn.Open();
                var querySprzet = "UPDATE sprzet SET dostepny = true WHERE id = @sprzetId";
                var queryWypozyczenie = "UPDATE wypozyczenia SET dataZwrotu = @dataZwrotu WHERE sprzetId = @sprzetId AND dataZwrotu IS NULL";

                using (var transaction = conn.BeginTransaction())
                {
                    using (var cmdWypozyczenie = new MySqlCommand(queryWypozyczenie, conn, transaction))
                    {
                        cmdWypozyczenie.Parameters.AddWithValue("@sprzetId", sprzetId);
                        cmdWypozyczenie.Parameters.AddWithValue("@dataZwrotu", dataZwrotu);
                        cmdWypozyczenie.ExecuteNonQuery();
                    }

                    using (var cmdSprzet = new MySqlCommand(querySprzet, conn, transaction))
                    {
                        cmdSprzet.Parameters.AddWithValue("@sprzetId", sprzetId);
                        cmdSprzet.ExecuteNonQuery();
                    }

                    transaction.Commit();
                    Console.WriteLine("Sprzęt został zwrócony.");
                }
            }
        }
        public void ZarezerwujSprzet(int sprzetId, int klientId, DateTime dataRezerwacji)
        {
            using (var conn = new MySqlConnection(connectionString))
            {
                conn.Open();
                var querySprzet = "UPDATE sprzet SET dostepny = false WHERE id = @sprzetId AND dostepny = true";
                var queryRezerwacja = "INSERT INTO rezerwacje (sprzetId, klientId, dataRezerwacji) VALUES (@sprzetId, @klientId, @dataRezerwacji)";

                using (var transaction = conn.BeginTransaction())
                {
                    using (var cmdSprzet = new MySqlCommand(querySprzet, conn, transaction))
                    {
                        cmdSprzet.Parameters.AddWithValue("@sprzetId", sprzetId);
                        var result = cmdSprzet.ExecuteNonQuery();
                        if (result == 0)
                        {
                            // Sprzęt nie jest dostępny lub nie istnieje
                            Console.WriteLine("Sprzęt nie jest dostępny lub nie istnieje.");
                            return;
                        }
                    }

                    using (var cmdRezerwacja = new MySqlCommand(queryRezerwacja, conn, transaction))
                    {
                        cmdRezerwacja.Parameters.AddWithValue("@sprzetId", sprzetId);
                        cmdRezerwacja.Parameters.AddWithValue("@klientId", klientId);
                        cmdRezerwacja.Parameters.AddWithValue("@dataRezerwacji", dataRezerwacji);
                        cmdRezerwacja.ExecuteNonQuery();
                    }

                    transaction.Commit();
                    Console.WriteLine("Rezerwacja została zarejestrowana.");
                }
            }
        }
        public void AnulujRezerwacje(int rezerwacjaId)
        {
            using (var conn = new MySqlConnection(connectionString))
            {
                conn.Open();
                var querySprzet = "UPDATE sprzet SET dostepny = true WHERE id = (SELECT sprzetId FROM rezerwacje WHERE id = @rezerwacjaId)";
                var queryRezerwacja = "DELETE FROM rezerwacje WHERE id = @rezerwacjaId";

                using (var transaction = conn.BeginTransaction())
                {
                    using (var cmdSprzet = new MySqlCommand(querySprzet, conn, transaction))
                    {
                        cmdSprzet.Parameters.AddWithValue("@rezerwacjaId", rezerwacjaId);
                        var result = cmdSprzet.ExecuteNonQuery();
                        if (result == 0)
                        {
                            // Rezerwacja nie istnieje lub nie udało się zaktualizować stanu sprzętu
                            Console.WriteLine("Nie udało się anulować rezerwacji.");
                            return;
                        }
                    }

                    using (var cmdRezerwacja = new MySqlCommand(queryRezerwacja, conn, transaction))
                    {
                        cmdRezerwacja.Parameters.AddWithValue("@rezerwacjaId", rezerwacjaId);
                        cmdRezerwacja.ExecuteNonQuery();
                    }

                    transaction.Commit();
                    Console.WriteLine("Rezerwacja została anulowana.");
                }
            }
        }


    }
}
