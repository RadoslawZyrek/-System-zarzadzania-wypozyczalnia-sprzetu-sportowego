﻿using ProjektW68564;

namespace System_Zarządzania_Wypożyczalnią_Sprzętu_Sportowego
{
    internal class Rezerwacja
    {
        public int? Id { get; set; }
        public Sprzet Sprzet { get; set; }
        public Klient Klient { get; set; }
        public DateTime DataRezerwacji { get; set; }


        public Rezerwacja(int id, Sprzet sprzet, Klient klient, DateTime dataRezerwacji)
        {
            Id = id;
            Sprzet = sprzet;
            Klient = klient;
            DataRezerwacji = dataRezerwacji;
        }

        public override string ToString()
        {
            return $"Rezerwacja {Id}: Sprzęt: {Sprzet.Nazwa}, Klient: {Klient.ImieNazwisko}, Data: {DataRezerwacji}";
        }
    }
}
