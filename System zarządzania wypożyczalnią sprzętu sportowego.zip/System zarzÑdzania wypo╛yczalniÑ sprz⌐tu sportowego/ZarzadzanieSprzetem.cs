﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySqlConnector;
namespace ProjektW68564
{
    internal class ZarzadzanieSprzetem
    {
        private string connectionString = "server=localhost;database=projekt;uid=root;pwd=;";

        private List<Sprzet> listaSprzetu;
        public ZarzadzanieSprzetem()
        {
            listaSprzetu = new List<Sprzet>();
        }
        public void DodajNowySprzet(string nazwa, string typ, decimal cenaWypozyczenia, bool dostepny)
        {
            int noweId = listaSprzetu.Count + 1; // Tworzenie nowego ID na podstawie liczby obiektów na liście
            Sprzet nowySprzet = new Sprzet(noweId, nazwa, typ, cenaWypozyczenia, dostepny);
            listaSprzetu.Add(nowySprzet);
            Console.WriteLine("Dodano nowy sprzęt.");
            using (MySqlConnection conn = new MySqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    string query = "INSERT INTO sprzet (nazwa, typ, cenaWypozyczenia, dostepny) VALUES (@nazwa, @typ, @cenaWypozyczenia, @dostepny)";
                    using (MySqlCommand cmd = new MySqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@nazwa", nazwa);
                        cmd.Parameters.AddWithValue("@typ", typ);
                        cmd.Parameters.AddWithValue("@cenaWypozyczenia", cenaWypozyczenia);
                        cmd.Parameters.AddWithValue("@dostepny", dostepny);
                        cmd.ExecuteNonQuery();
                    }
                    Console.WriteLine("Sprzęt został pomyślnie dodany do bazy danych.");
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Wystąpił błąd podczas dodawania sprzętu do bazy danych: " + ex.Message);
                }
            }
        }

        public void EdytujSprzet(int id, Sprzet nowySprzet)
        {
            using (MySqlConnection conn = new MySqlConnection(connectionString))
            {
                try
                {
                    conn.Open();

                    string query = "UPDATE sprzet SET nazwa = @nazwa, typ = @typ, cenaWypozyczenia = @cenaWypozyczenia, dostepny = @dostepny WHERE id = @id";
                    using (MySqlCommand cmd = new MySqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@id", id);
                        cmd.Parameters.AddWithValue("@nazwa", nowySprzet.Nazwa);
                        cmd.Parameters.AddWithValue("@typ", nowySprzet.Typ);
                        cmd.Parameters.AddWithValue("@cenaWypozyczenia", nowySprzet.CenaWypozyczenia);
                        cmd.Parameters.AddWithValue("@dostepny", nowySprzet.Dostepny);

                        int rowsAffected = cmd.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            Console.WriteLine("Sprzęt sportowy został zaktualizowany.");
                        }
                        else
                        {
                            Console.WriteLine("Nie znaleziono sprzętu o podanym identyfikatorze.");
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Wystąpił błąd podczas aktualizacji sprzętu: " + ex.Message);
                }
            }
        }
        public void UsunSprzet(int id)
        {


            using (MySqlConnection conn = new MySqlConnection(connectionString))
            {
                try
                {
                    conn.Open();

                    string query = "DELETE FROM sprzet WHERE id = @id";
                    using (MySqlCommand cmd = new MySqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@id", id);

                        int rowsAffected = cmd.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            Console.WriteLine("Sprzęt sportowy został usunięty.");
                        }
                        else
                        {
                            Console.WriteLine("Nie znaleziono sprzętu o podanym identyfikatorze.");
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Wystąpił błąd podczas usuwania sprzętu: " + ex.Message);
                }
            }
        }
        public void WczytajDaneSprzetuZBazyDanych()
        {
            ;// Wyczyść listę przed dodaniem nowych danych

            try
            {
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();

                    string query = "SELECT * FROM sprzet";

                    using (MySqlCommand cmd = new MySqlCommand(query, conn))
                    {
                        using (MySqlDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                int id = Convert.ToInt32(reader["Id"]);
                                string nazwa = reader["Nazwa"].ToString();
                                string typ = reader["Typ"].ToString();
                                decimal cena = Convert.ToDecimal(reader["CenaWypozyczenia"]);
                                bool dostepny = Convert.ToBoolean(reader["Dostepny"]);

                                // Tworzenie obiektu sprzętu i dodawanie go do listy
                                Sprzet sprzet = new Sprzet(id, nazwa, typ, cena, dostepny);
                                listaSprzetu.Add(sprzet);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Wystąpił błąd podczas wczytywania danych z bazy danych: {ex.Message}");
            }
        }
        public void WyswietlSprzet()
        {
            Console.WriteLine("Lista dostępnego sprzętu sportowego:");
            foreach (var sprzet in listaSprzetu)
            {
                Console.WriteLine($"Id: {sprzet.Id}, Nazwa: {sprzet.Nazwa}, Typ: {sprzet.Typ}, Cena: {sprzet.CenaWypozyczenia}, Dostępny: {sprzet.Dostepny}");
            }
            Console.WriteLine("\nNaciśnij dowolny klawisz aby kontynuować...");
            Console.ReadKey(); 
        }
    }
}
