﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjektW68564
{
    internal class Klient
    {
        public int Id { get; set; }
        public string? ImieNazwisko { get; set; }
        public string? NumerTelefonu { get; set; }

        public Klient() { }

        public Klient(int id, string imieNazwisko, string numerTelefonu)
        {
            Id = id;
            ImieNazwisko = imieNazwisko;
            NumerTelefonu = numerTelefonu;
        }
    }
}
